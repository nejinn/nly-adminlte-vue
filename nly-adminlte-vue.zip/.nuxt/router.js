import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2cde71f3 = () => interopDefault(import('..\\docs\\pages\\docs\\index.js' /* webpackChunkName: "pages_docs_index" */))
const _4540581f = () => interopDefault(import('..\\docs\\pages\\play.vue' /* webpackChunkName: "pages_play" */))
const _87ab0fee = () => interopDefault(import('..\\docs\\pages\\docs\\components\\index.js' /* webpackChunkName: "pages_docs_components_index" */))
const _41cfa577 = () => interopDefault(import('..\\docs\\pages\\docs\\directives\\index.js' /* webpackChunkName: "pages_docs_directives_index" */))
const _4d35ce3f = () => interopDefault(import('..\\docs\\pages\\docs\\layout.js' /* webpackChunkName: "pages_docs_layout" */))
const _8c34ae42 = () => interopDefault(import('..\\docs\\pages\\docs\\misc\\index.js' /* webpackChunkName: "pages_docs_misc_index" */))
const _2ce05bbc = () => interopDefault(import('..\\docs\\pages\\docs\\reference\\index.js' /* webpackChunkName: "pages_docs_reference_index" */))
const _77433b5e = () => interopDefault(import('..\\docs\\pages\\docs\\components\\_slug.js' /* webpackChunkName: "pages_docs_components__slug" */))
const _4a038fbf = () => interopDefault(import('..\\docs\\pages\\docs\\directives\\_slug.js' /* webpackChunkName: "pages_docs_directives__slug" */))
const _7bccd9b2 = () => interopDefault(import('..\\docs\\pages\\docs\\misc\\_slug.js' /* webpackChunkName: "pages_docs_misc__slug" */))
const _1c78872c = () => interopDefault(import('..\\docs\\pages\\docs\\reference\\_slug.js' /* webpackChunkName: "pages_docs_reference__slug" */))
const _b59c4f12 = () => interopDefault(import('..\\docs\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/docs",
    component: _2cde71f3,
    name: "docs"
  }, {
    path: "/play",
    component: _4540581f,
    name: "play"
  }, {
    path: "/docs/components",
    component: _87ab0fee,
    name: "docs-components"
  }, {
    path: "/docs/directives",
    component: _41cfa577,
    name: "docs-directives"
  }, {
    path: "/docs/layout",
    component: _4d35ce3f,
    name: "docs-layout"
  }, {
    path: "/docs/misc",
    component: _8c34ae42,
    name: "docs-misc"
  }, {
    path: "/docs/reference",
    component: _2ce05bbc,
    name: "docs-reference"
  }, {
    path: "/docs/components/:slug",
    component: _77433b5e,
    name: "docs-components-slug"
  }, {
    path: "/docs/directives/:slug",
    component: _4a038fbf,
    name: "docs-directives-slug"
  }, {
    path: "/docs/misc/:slug",
    component: _7bccd9b2,
    name: "docs-misc-slug"
  }, {
    path: "/docs/reference/:slug",
    component: _1c78872c,
    name: "docs-reference-slug"
  }, {
    path: "/",
    component: _b59c4f12,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
